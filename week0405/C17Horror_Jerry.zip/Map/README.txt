C17Horror

+ OVERVIEW
 - This is a Half-Life 2 map (mod) that adds extra content to the original gameplay. In this map, you as Dr. Freeman wake up from a car 
   crash, try to escape from C-17 fierce fight, and successfully meet with Barney.
 - Estimated playtime: 20 minutes

+ DEVELOPER
 - Jerry (Zeyuan) Hu
 - Twitter: @xxks_kkk
 - GitHub: xxks-kkk
 - Email: ferrishu3886@gmail.com

+ LICENSE
 - Creative Commons Attribution-ShareAlike 4.0 International License.

+ DEVELOPMENT INFO
 - Game: Half-Life 2
 - Genre: First-Person Shooter
 - Engine: Source
 - Development Time: 2 weeks
 - Game Mode: Single-player mission

+ RESPONSIBILITIES
 - Concept & Documentation
 - Construction & Lighting
 - Scripting (Gameplay, FX, Audio)
 - AI Pathing

+ REQUIREMENT

 - Half-Life 2
 - Half-Life 2: Lost Coast 
 	- Note: Technically, this mod is usable under Half-Life 2 only, but you may face some texture error. This is due to availability 
                of some textures. Some textures are only available for Half-Life 2: Lost Coast. In order to have full experience, this mod                 is recommended to use with Half-Life 2: Lost Coast

+ USAGE
 - after unzip the file, find C17Horror.bsp
 - place it in your Half-Life 2 maps folder
   	- Windows: X:\..\Steam\SteamApps\common\Half-Life 2\hl2\maps
	- Mac: /Users/<YOURUSERNAME>/Library/Application Support/Steam/SteamApps/common/Half-Life 2/hl2/maps
 - Open your steam, right click on Half-Life 2 name in your library, click "Properties" -> "SET LAUNCH OPTIONS", type in "-console"
   (This will allow you to use console in game)
 - Run Half-Life 2, press "`" to open up console, then type "map C17Horror", and then press enter to load the map.

Have Fun!